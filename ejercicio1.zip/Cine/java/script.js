var nombres = [
    {title: " Avengers End Game",
     tiempo: "3H 5Minutos",
     clasificacion: " +A || Formato de Película: 2D || Butacas: Tradicionales, VIP",
     synopsis: " Los vengadores ",
     funciones:"1:00-3:05",
     imagen: "./img/01.jpg"
    },
    {title: " Black Adam ",
     tiempo: "1H 30 minutos",
     clasificacion: " +A || Formato de Película: 2D  Butacas: Tradicionales, Familiar, VIP",
     synopsis: " Los vengadores ",
     funciones:"4:30-6:00",
     imagen: "./img/02.jpg"
    },
    {title: " Free Guy 2021",
    tiempo: "1H 42 minutos",
     clasificacion: " +A || Formato de Película: 2D  Butacas: Familiar, VIP",
     synopsis: " Los vengadores ",
     funciones:"1:30-3:00",
     imagen: "./img/03.jpg"

    }
    
];
    
    //Obteniendo el elemento contenedor donde se cargarán
    //todos los datos del objeto JSON
    var div = document.getElementById("info");
    div.innerHTML = volcarDatos(nombres);
    function volcarDatos(datos){
    var total = datos.length;
    data = "<ul class=\"grid\">\n";
    for(var i=0; i<total; i++){
    data += "<li class=\"box\">\n";
    data += "<card class=\"box-shadow\"></card>\n";
    data += "<card class=\"box-gradient\">\n";
    data += "<img src=\"" + datos[i].imagen + "\" alt=\"Portada de " + datos[i].title + " " + datos[i].title + "\" class=\"portada\" />\n\n";
    data += "<h4>\nPelicula: " + datos[i].title +"\n</h4>\n";
    data += "<p>\nDuración: " + datos[i].tiempo + "\n<br />\n";
    data += "<p>\nClasificacion: " + datos[i].clasificacion + "\n<br />\n";
    data += "<p>\nDescripcion: " + datos[i].synopsis + "\n<br />\n";
    data += "<p>\nHorarios: " + datos[i].funciones + "\n<br />\n";
    data += "</div>\n";
    data += "</li>\n";
    }
    data += "</ul>\n";
    return data;
    }